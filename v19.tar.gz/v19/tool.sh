#! /bin/bash

echo > bochsout.txt

# rm -rvf mhome/cg/os/pegasus-os/v3/*.bin

make clean

make

